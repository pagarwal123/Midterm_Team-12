data <- split_dataset_final[[1]]
data <- data[,c(18,6,8,9,10,19,20,21,22,24,26,16)]
json_data <- fromJSON(paste(readLines("config.json"), collapse=""))
#nstart tells how many times algorithm
km.out <- kmeans(data,as.numeric(json_data$Number_of_clusters),nstart = as.numeric(json_data$nstart))
names(km.out)

#kmeans results
km.out$cluster

#cluster tagging
View(cbind(data,km.out$cluster))
View(data)
#k-mean results with k=3

#Scatter plot matrix
plot(data, col=(km.out$cluster), main = "K-mean results")

error.freq.long <- gather(data, tag, freq)


#### Hierarchical clustering
rough_data <- sample(1:nrow(data),round(0.60*nrow(data)))                        

k_mean_data <- data[rough_data,]
kmeans_testdata <- data[-rough_data,]

#Scaling the data
data=scale(k_mean_data) 
# Complete linkage type
hc.complete=hclust(dist(data),method="complete") 
# Average linkage type
hc.average=hclust(dist(data),method="average") 

par(mfrow=c(1,2)) #Plotting in a matrix form
plot(hc.complete,main='Complete')


### Bend Graph
rough_data <- sample(1:nrow(data),round(0.75*nrow(data)))                        
k_mean_data <- data[rough_data,]
nrow(k_mean_data)
names(data)
data=scale(k_mean_data) 
#Scaling the data
wss <- (nrow(data)-1)*sum(apply(data,2,var))
for(i in 2:15){
  wss[i] <- sum(kmeans(data,centers = i)$withinss)
}

plot(1:15, wss,type="b",xlab = "Number of clusters", ylab="Within groups sum of squares")
