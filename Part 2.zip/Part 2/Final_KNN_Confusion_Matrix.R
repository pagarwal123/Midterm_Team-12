#look up the structure of the dataset#
data_knn <- split_dataset_final[[1]]
data_knn <- data_knn[,c(18,6,8,9,10,12,16,14,19,20,21,22,24,26,28)]

str(data_knn)
head(data_knn)
table(data_knn$Base_Hour_Class)

#Mix up dataset#
set.seed(9850)
group<- runif(nrow(data_knn))
data_knn<- data_knn[order(group),]
summary(data_knn[, c(1:14)])

#Normalization#
normalize<-function(x)(return((x-min(x))/(max(x)-min(x))))
data_knn_n<-as.data.frame(lapply(data_knn[,c(1:7,9:14)],normalize))
summary(data_knn_n)

#Separate training&testing dataset
data_knn_n_train<-data_knn_n[1:7000, ]
data_knn_n_test<-data_knn_n[7001:8211, ]
data_knn_train_target<-data_knn[1:7000,15]
data_knn_test_target<-data_knn[7001:8211,15]

# fit in knn algorithm
require(class)
m1<- knn(train= data_knn_n_train, test= data_knn_n_test, cl=as.factor(data_knn_train_target[['Base_Hour_Class']]), k=92)
table(as.factor(data_knn_test_target[['Base_Hour_Class']]),m1)

#install.packages("gmodels")

library(gmodels)
#result and comparison 

CrossTable(x=as.factor(data_knn_test_target[['Base_Hour_Class']]), y=m1, prop.chisq = FALSE)
Final_data <- data_knn[7001:8211,]
Prediction_value <- as.data.frame(m1[1:nrow(Final_data)])
colnames(Prediction_value) <- c("Prediction_value")
Final_data <- cbind(Final_data, Prediction_value)
Final_data <- Final_data %>% mutate(OutlierDay = ifelse(Prediction_value != Base_Hour_Class , "False", "True"))

write.csv(Final_data,"knn_Classification_5198_1.csv")

pred_knn <- prediction(prob, cl_testing)
pred_knn <- performance(pred_knn, "tpr", "fpr")
plot(pred_knn, avg= "threshold", colorize=T, lwd=3, main="Voilà, a ROC curve!")
