install.packages("FNN")
library(FNN)
data2 <- split_dataset_final[[1]]
data2 <- data2[,c(18,6,8,9,10,12,19,21,22,16,26)]
data2 <- as.data.frame(data2)
data_original <- data2

train <- sample(1:nrow(data2),round(0.75*nrow(data2)))
traindata <- data2[train,]
testdata <- data2[-train,]

tree_knn<-knn.reg(traindata,y=traindata$Normalized_Consumption,testdata,k=3)
testdata$Normalized_Consumption

error=as.double(tree_knn[[4]])-testdata$Normalized_Consumption
error <- as.data.frame(error)
performance <- accuracy(tree_knn[[4]],testdata$Normalized_Consumption)
tree_knn[[4]] <- as.data.frame(tree_knn[[4]])
colnames(tree_knn[[4]]) <- c("Predicted value")
Final_prediction_knn_reg <- cbind(testdata, tree_knn[[4]])
Final_prediction_knn_reg$residual <- Final_prediction_knn_reg$Normalized_Consumption - 
  Final_prediction_knn_reg$`Predicted value`
standard_deviation <- sd(Final_prediction_knn_reg$residual)
Final_prediction_knn_reg <- Final_prediction_knn_reg %>% mutate(Outlier_Tag = ifelse(residual >= (2*standard_deviation) , 1, 0))
knnReg_RMSE <- performance[2]
write.csv( Final_prediction_knn_reg, "5198_1_knn_reg_Prediction.csv")
write.csv(performance, "5198_1_knn_reg_performance.csv")
