#Some descriptive statistics of Consumption data
data_logi <- split_dataset_final[[1]]
#data_logi <- data_logi[,c(18,6,8,9,10,12,16,14,19,20,21,22,24,26,28)]

summary(data_logi)

data_logi$Base_Hour_Class <- as.factor(data_logi$Base_Hour_Class)
table(data_logi$Base_Hour_Class)

#Construct a logistic regression model for factor Base_Hour_Class using all other variables 
fit1<-glm(Base_Hour_Class~month+hour+TemperatureF+Dew_PointF+Humidity+Sea_Level_PressureIn+VisibilityMPH+WindDirDegrees+Wind_SpeedMPH+Normalized_Consumption
         +dayOfWeek+Weekday+Holiday,data=data_logi,family=binomial(link="logit"))

summary(fit1)

#Construct a logistic regression model for factor Base_Hour_Class 
fit2 <- glm(Base_Hour_Class ~ month + Sea_Level_PressureIn + Normalized_Consumption + Weekday,
            data=data_logi, family=binomial(link="logit"))
summary(fit2)

#Parameters of fit2
coef(fit2)

#Predict the probability of the outcome
newdata <- data.frame(month=mean(data_logi$month),
                      Sea_Level_PressureIn=mean(data_logi$Sea_Level_PressureIn),
                      Normalized_Consumption=mean(data_logi$Normalized_Consumption),
                      Weekday=mean(data_logi$Weekday))
newdata
prob <- predict(fit2, newdata=newdata, type="response")
prob


#Split the data into training and testing
smp_size <- floor(0.80 * nrow(data_logi))
set.seed(123)
train_ind <- sample(seq_len(nrow(data_logi)), size = smp_size)
train <- data_logi[train_ind,]
test <- data_logi[-train_ind,]
#Build a logistic regression model on the training data
fit <- glm(Base_Hour_Class ~ month + Sea_Level_PressureIn + Normalized_Consumption + Weekday,
            data=train, family=binomial(link="logit"))
summary(fit)

#Run the model on the test set with cutoff value = 0.5
test.probs <- predict(fit,test,type="response")
pred <- rep("High",length(test.probs))
pred[test.probs>=0.5] <- "Low"

#classification matrix using confusionMatrix() function in caret package
library(caret)
confusionMatrix(test$Base_Hour_Class, pred)
#Generate ROC curve using ROCR package
library(ROCR)
prediction <- prediction(test.probs, test$Base_Hour_Class)
performance <- performance(prediction, measure = "tpr",x.measure = "fpr")
plot(performance, main = "ROC curve", xlab = "1-Specificity", ylab = "Sensitivity")

#Generate cumulative lift curve using lift() function in caret package
test$probs = test.probs
test$probs = sort(test$probs, decreasing = T)
lift <- lift(Base_Hour_Class ~ prob, data = test)
lift
xyplot(lift, plot = "gain")

test_data <- test[,c(10,21,16,9,28)]
test_data <- as.data.frame(test_data)
prediction_data <- as.data.frame(pred)
test_data <- cbind(test_data, prediction_data)
test_data <- test_data %>% mutate(OutlierDay = ifelse(pred != OutlierDay , "False", "True"))

write.csv(test_data,"Logistic_Regression_5198_1.csv")




