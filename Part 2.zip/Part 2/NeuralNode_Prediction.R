#cue.v.fwmrm.net
set.seed(123)
data2 <- split_dataset_final[[1]]
data2 <- data2[,c(18,6,8,9,10,12,19,21,22,16,26)]
data2 <- as.data.frame(data2)
data_original <- data2
apply(data2,2,function(x) sum(is.na(x)))
normalize<-function(x)(return((x-min(x))/(max(x)-min(x))))
data1<-as.data.frame(lapply(data2[,c(1:9,11)],normalize))
data3 <- as.data.frame(data2$Normalized_Consumption)
colnames(data3) <- c("Normalized_Consumption")
data <- cbind(data1, data3)

index <- sample(1:nrow(data),round(0.75*nrow(data)))
index_original <- index
train <- data[index,]
test <- data[-index,]
lm.fit <- glm(Normalized_Consumption~TemperatureF+hour+dayOfWeek+Weekday+month
              +Holiday+Dew_PointF+Sea_Level_PressureIn 
              +VisibilityMPH+WindDirDegrees
              , data=train)
summary(lm.fit)
pr.lm <- predict(lm.fit,test)
MSE.lm <- sum((pr.lm - test$Normalized_Consumption)^2)/nrow(test)


#Preparing to fit the neural network
maxs <- apply(data, 2, max) 
mins <- apply(data, 2, min)

scaled <- as.data.frame(scale(data, center = mins, scale = maxs - mins))
train_ <- scaled[index,]
test_ <- scaled[-index,]

n <- names(train_)
f <- as.formula(paste("Normalized_Consumption ~", paste(n[!n %in% "Normalized_Consumption"], collapse = " + ")))
nn <- neuralnet(f,data=train_,hidden=2,linear.output=T)
nn <- neuralnet(f,data=train_,hidden=2,linear.output=T)
plot(nn)
print(nn)


#Predicting Normalized Consumption using the neural network

pr.nn <- compute(nn,test_[,1:10])
pr.nn_ <- pr.nn$net.result*(max(data$Normalized_Consumption)-
                              min(data$Normalized_Consumption))+min(data$Normalized_Consumption)
test.r <- (test_$Normalized_Consumption)*(max(data$Normalized_Consumption)-
                                            min(data$Normalized_Consumption))+min(data$Normalized_Consumption)
MSE.nn <- sum((test.r - pr.nn_)^2)/nrow(test_)
#we then compare the two MSEs

print(paste(MSE.lm,MSE.nn))

#Apparently the net is doing a better work than the linear model at predicting medv. Once again, be careful because this result depends on the train-test split performed above. Below, after the visual plot, we are going to perform a fast cross validation in order to be more confident about the results.
#A first visual approach to the performance of the network and the linear model on the test set is plotted below

par(mfrow=c(1,2))
plot(test$Normalized_Consumption,pr.nn_,col='red',main='Real vs predicted NN',pch=18,cex=0.7)
abline(0,1,lwd=2)
legend('bottomright',legend='NN',pch=18,col='red', bty='n')

plot(test$Normalized_Consumption,pr.lm,col='blue',main='Real vs predicted lm',pch=18, cex=0.7)
abline(0,1,lwd=2)
legend('bottomright',legend='LM',pch=18,col='blue', bty='n', cex=.95)

#By visually inspecting the plot we can see that the predictions made by 
#the neural network are (in general) more concetrated around the line 
#(a perfect alignment with the line would indicate a MSE of 0 and thus an ideal perfect prediction) 
#than those made by the linear model.

plot(test$Normalized_Consumption,pr.nn_,col='red',main='Real vs predicted NN',pch=18,cex=0.7)
points(test$Normalized_Consumption,pr.lm,col='blue',pch=18,cex=0.7)
abline(0,1,lwd=2)
legend('bottomright',legend=c('NN','LM'),pch=18,col=c('red','blue'))

#Prediction

pr.nn_ <- as.data.frame(pr.nn_)
colnames(pr.nn_) <- c("Predicted value")
data2_test <- data_original[-index_original,]
Final_prediction_nn <- cbind(data2_test, pr.nn_)
Final_prediction_nn$residual <- Final_prediction_nn$Normalized_Consumption - 
                                Final_prediction_nn$`Predicted value`
standard_deviation <- sd(Final_prediction_nn[,10])
Final_prediction_nn <- Final_prediction_nn %>% mutate(Outlier_Tag = ifelse(residual >= (2*standard_deviation) , 1, 0))

#calculating mean square value
rmse(pr.nn_,data2_test$Normalized_Consumption )
rmse <- c("RMS", rmse(pr.nn_,data2_test$Normalized_Consumption))
mae <- c("MAE", mae(pr.nn_,data2_test$Normalized_Consumption))

# Function that returns Mean Absolute Percentage Error

mape <- abs((Final_prediction_nn$residual/Final_prediction_nn$Normalized_Consumption)*100)
mape <- mean(mape) 
mape <- c("MAPE", mape)
neural_performance <- rbind(rmse, mae, mape, deparse.level = 0)
NEURALnode_RMSE <- rmse(pr.nn_,data2_test$Normalized_Consumption )[[1]]
write.csv( Final_prediction_nn, "5198_1_Neural_Prediction.csv")
write.csv(neural_performance, "5198_1_neural_performance.csv")





