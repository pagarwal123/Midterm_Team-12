
set.seed(123)
data <- split_dataset_final[[1]]
data <- data[,c(18,6,8,9,10,12,7,14,19,20,21,22,24,26,28)]
data$Base_Hour_Class <- as.factor(data$Base_Hour_Class)
library(randomForest)
table(data$Base_Hour_Class)/nrow(data)
#High          Low 
#0.5353793691 0.4646206309

#53% of the observations has target variable “High” and remaining 46% observations take value “Low”.

#Now, we will split the data sample into development and validation samples.

sample.ind <- sample(2, 
                     nrow(data),
                     replace = T,
                     prob = c(0.6,0.4))
cross.sell.dev <- data[sample.ind==1,]
cross.sell.val <- data[sample.ind==2,]

table(cross.sell.dev$Base_Hour_Class)/nrow(cross.sell.dev)
#        High          Low 
#0.5331720105 0.4668279895  

table(cross.sell.val$Base_Hour_Class)/nrow(cross.sell.val)
#High          Low 
#0.5387453875 0.4612546125 

class(cross.sell.dev$Base_Hour_Class)

## [1] "factor"

varNames <- names(cross.sell.dev)
# Exclude ID or Response variable
varNames <- varNames[!varNames %in% c("Base_Hour_Class")]

# add + sign between exploratory variables
varNames1 <- paste(varNames, collapse = "+")

# Add response variable and convert to a formula object
rf.form <- as.formula(paste("Base_Hour_Class", varNames1, sep = " ~ "))

cross.sell.rf <- randomForest(rf.form,
                              cross.sell.dev,
                              ntree=500,
                              importance=T)

plot(cross.sell.rf)

# Variable Importance Plot
varImpPlot(cross.sell.rf,
           sort = T,
           main="Variable Importance",
           n.var=5)

# Variable Importance Table
var.imp <- data.frame(importance(cross.sell.rf,
                                 type=2))
# make row names as columns
var.imp$Variables <- row.names(var.imp)
var.imp[order(var.imp$MeanDecreaseGini,decreasing = T),]

# Predicting response variable
cross.sell.dev$predicted.response <- predict(cross.sell.rf ,cross.sell.dev)

#Confusion Matrix

#confusionMatrix function from caret package can be used for creating confusion matrix based on actual response variable and predicted value.

# Load Library or packages
library(e1071)
library(caret)
## Loading required package: lattice
## Loading required package: ggplot2
# Create Confusion Matrix
confusionMatrix(data=cross.sell.dev$predicted.response,
                reference=cross.sell.dev$Base_Hour_Class,
                positive='Low')

# Predicting response variable
cross.sell.val$predicted.response <- predict(cross.sell.rf ,cross.sell.val)

# Create Confusion Matrix
confusionMatrix(data=cross.sell.val$predicted.response,
                reference=cross.sell.val$Base_Hour_Class,
                positive='Low')

cross.sell.val <- as.data.frame(cross.sell.val)
cross.sell.val <- cross.sell.val %>% mutate(OutlierDay = ifelse(predicted.response[[1]] != Base_Hour_Class , "False", "True"))

write.csv(cross.sell.val, "Random_Forest_classification_5198_1.csv")

cross.rf.pr = predict(cross.rf,type="prob",newdata=data$val)[,2]
cross.rf.pred = prediction(cross.rf.pr, data$val)
cross.rf.perf = performance(cross.rf.pred,"tpr","fpr")
plot(cross.rf.perf,main="ROC Curve for Random Forest",col=2,lwd=2)
abline(a=0,b=1,lwd=2,lty=2,col="gray")



