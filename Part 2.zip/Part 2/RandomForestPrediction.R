# Random Forests
# Random forests improve predictive accuracy by generating a large number of bootstrapped trees (based on random samples of variables), classifying a case using each tree in this new "forest", and deciding a final predicted outcome by combining the results across all of the trees (an average in regression, a majority vote in classification). Breiman and Cutler's random forest approach is implimented via the randomForest package.

library(randomForest)
set.seed(123)
data_reg_random_forest <- split_dataset_final[[1]]
index_1 <- sample(1:nrow(data_reg_random_forest),round(0.75*nrow(data_reg_random_forest)))
index_original_1 <- index_1
train <- data_reg_random_forest[index_1,]
test <- data_reg_random_forest[-index_1,]

fit <- randomForest(Normalized_Consumption ~ TemperatureF+hour+Weekday+month
                    +Dew_PointF +WindDirDegrees +Humidity,   data = train)
print(fit) # view results 
importance(fit) # importance of each predictor
predicion_random_forest <- predict(fit, test)

data2_test <- test[,c(18,6,9,10,19,26,20,16)]
predicion_random_forest <- as.data.frame(predicion_random_forest)
Final_prediction_rr <- cbind(data2_test, predicion_random_forest)
Final_prediction_rr$residual <- Final_prediction_rr$Normalized_Consumption - 
  Final_prediction_rr$predicion_random_forest
standard_deviation <- sd(Final_prediction_rr$residual)
Final_prediction_rr <- Final_prediction_rr %>% 
  mutate(Outlier_Tag = ifelse(residual >= (2*standard_deviation) , 1, 0))

#calculating mean square value
randomforest_performance <- accuracy(predicion_random_forest, Final_prediction_rr$Normalized_Consumption)
#----------------------------------------------------------------------------------------

write.csv( Final_prediction_rr, "5198_1_RandomForest_Prediction.csv")
write.csv(randomforest_performance, "5198_1_RandomForest_performance.csv")
plot(fit, log="y")
varImpPlot(fit)

