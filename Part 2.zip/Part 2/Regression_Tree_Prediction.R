library(tree)
library(MASS)
library(ISLR)

#fit a regression tree to the  data set. create a training set, and fit the tree to the training data.
set.seed(123)
data_reg_tree <- split_dataset_final[[1]]
data_reg_tree <- data_reg_tree[,c(18,6,9,10,12,14,19,20,26,16)]

train = sample (1:nrow(data_reg_tree), nrow(data_reg_tree)/2)
tree.data = tree(Normalized_Consumption~.,data_reg_tree,subset=train)
summary (tree.data)
variable_unique <- unique(tree.data$frame$var)
variable_unique <- as.character(variable_unique)
variable_unique <- variable_unique[-3]
#plot the tree.
plot (tree.data)
text (tree.data, pretty = 0)
#Cross-validation for Choosing Tree Complexity
cv.data = cv.tree (tree.data)
plot (cv.data$size, cv.data$dev, type='b')
#prune the tree, we could use the prune.tree() function:
prune.data =prune.tree(tree.data, best = 5)
plot(prune.data)
text(prune.data, pretty = 0)
#In keeping with the cross-validation results, we use the unpruned tree to make predictions on the test set.
yhat=predict (tree.data, newdata =data_reg_tree [-train,])
data.test=data_reg_tree [-train,"Normalized_Consumption"]
data.test1 <- as.double(data.test[['Normalized_Consumption']])
plot(yhat,data.test1)
abline (0,1)
#MSE
mean((yhat -data.test)^2)
accuracy_1 <- accuracy(yhat, data.test1)

#After removing the least important splits, the MSE only increases a little
yhat=predict (prune.data, newdata =data_reg_tree [-train,])
data.test=data_reg_tree [-train,"Normalized_Consumption"]
data.test1 <- as.double(data.test[['Normalized_Consumption']])
plot(yhat,data.test1)
abline (0,1)
#MSE
mean((yhat -data.test)^2)
accuracy_2 <- accuracy(yhat, data.test1)

test <- as.data.frame( data_reg_tree [-train,variable_unique])
yhat_1 <- as.data.frame(yhat)
colnames(yhat_1) <- c("Predicted Value")
data.test_1 <- as.data.frame(data.test)
Final_prediction <- cbind(test,yhat_1,data.test_1)
Final_prediction$residual <- Final_prediction$Normalized_Consumption - 
  Final_prediction_nn$`Predicted value`
standard_deviation <- sd(Final_prediction$residual)
Final_prediction <- Final_prediction %>% mutate(Outlier_Tag = ifelse(residual >= (2*standard_deviation) , 1, 0))
regression_tree_rmse <- accuracy_2[2]
write.csv( Final_prediction, "5198_1_Regression_Prediction.csv")
write.csv(accuracy_2, "5198_1_Regression_performance.csv")



knnReg_RMSE
NEURALnode_RMSE
randomForest_RMSE
regression_tree_rmse

min(knnReg_RMSE, NEURALnode_RMSE, randomForest_RMSE, regression_tree_rmse)


